const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    // Local calendar day, "YYYY-MM-DD"
    date: { type: String, required: true },
    checkIn: { type: Date, required: true },
    checkOut: { type: Date },
    workedHours: { type: Number, default: 0 },
    status: { type: String, enum: ['present', 'late', 'half-day'], default: 'present' },
  },
  { timestamps: true }
);

// One attendance record per person per day
attendanceSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('Attendance', attendanceSchema);
