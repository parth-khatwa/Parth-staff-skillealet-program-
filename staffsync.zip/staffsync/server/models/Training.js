const mongoose = require('mongoose');

const trainingSchema = new mongoose.Schema(
  {
    title: { type: String, required: [true, 'Title is required'], trim: true, maxlength: 120 },
    description: { type: String, trim: true, maxlength: 1000, default: '' },
    trainer: { type: String, trim: true, default: '' },
    mode: { type: String, enum: ['online', 'offline'], default: 'online' },
    startDate: { type: Date, required: [true, 'Start date is required'] },
    endDate: { type: Date, required: [true, 'End date is required'] },
    assignedTo: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    completedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  },
  { timestamps: true, toJSON: { virtuals: true } }
);

// upcoming / ongoing / completed, worked out from the dates
trainingSchema.virtual('status').get(function () {
  const now = new Date();
  const end = new Date(this.endDate);
  end.setUTCHours(23, 59, 59, 999);
  if (now < this.startDate) return 'upcoming';
  if (now > end) return 'completed';
  return 'ongoing';
});

module.exports = mongoose.model('Training', trainingSchema);
