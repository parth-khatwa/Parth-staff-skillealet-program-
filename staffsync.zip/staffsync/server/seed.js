// Fills the database with demo data:  npm run seed
// WARNING: this DELETES all existing users, leaves, attendance, announcements and trainings.
require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const mongoose = require('mongoose');
const connectDB = require('./config/db');
const User = require('./models/User');
const Leave = require('./models/Leave');
const Attendance = require('./models/Attendance');
const Announcement = require('./models/Announcement');
const Training = require('./models/Training');
const { todayStr, addDays, atLocal, parseDateOnly } = require('./utils/dates');

const day = (offset) => parseDateOnly(addDays(todayStr(), offset));

const run = async () => {
  await connectDB();

  await Promise.all([
    User.deleteMany({}),
    Leave.deleteMany({}),
    Attendance.deleteMany({}),
    Announcement.deleteMany({}),
    Training.deleteMany({}),
  ]);

  // ---- Users (created one by one so passwords get hashed) ----
  const hr = await User.create({
    name: 'Anita Sharma', email: 'hr@staffsync.com', password: 'Hr@12345', role: 'hr',
    department: 'Human Resources', designation: 'HR Head', phone: '9800000001', salary: 90000,
    joiningDate: day(-900),
  });
  const manager = await User.create({
    name: 'Rahul Verma', email: 'manager@staffsync.com', password: 'Manager@123', role: 'manager',
    department: 'Engineering', designation: 'Engineering Manager', phone: '9800000002', salary: 120000,
    joiningDate: day(-700),
  });

  const staff = [
    { name: 'Priya Patel', email: 'employee@staffsync.com', designation: 'Frontend Developer', salary: 60000 },
    { name: 'Amit Singh', email: 'amit@staffsync.com', designation: 'Backend Developer', salary: 65000 },
    { name: 'Neha Joshi', email: 'neha@staffsync.com', designation: 'QA Engineer', salary: 50000 },
    { name: 'Karan Mehta', email: 'karan@staffsync.com', designation: 'DevOps Engineer', salary: 70000 },
  ];
  const employees = [];
  for (let i = 0; i < staff.length; i += 1) {
    employees.push(
      await User.create({
        ...staff[i],
        password: 'Employee@123',
        role: 'employee',
        department: 'Engineering',
        phone: `98000001${i}0`,
        manager: manager._id,
        joiningDate: day(-400 + i * 40),
      })
    );
  }
  const [priya, amit, neha, karan] = employees;

  // ---- Attendance for the last 14 days (skips Sundays) ----
  const everyone = [hr, manager, ...employees];
  const records = [];
  for (let back = 14; back >= 0; back -= 1) {
    const date = addDays(todayStr(), -back);
    if (new Date(`${date}T00:00:00Z`).getUTCDay() === 0) continue;
    everyone.forEach((u, idx) => {
      const roll = (back * 7 + idx * 3) % 10;
      if (roll === 0 && back !== 0) return; // absent
      const late = roll === 1 || roll === 2;
      const half = roll === 3 && back !== 0;
      const inTime = late ? '09:50' : `09:${String(5 + ((idx * 4 + back) % 20)).padStart(2, '0')}`;
      const checkIn = atLocal(date, inTime);
      const record = { user: u._id, date, checkIn, status: late ? 'late' : 'present' };
      if (back !== 0) {
        const checkOut = atLocal(date, half ? '12:45' : '18:10');
        record.checkOut = checkOut;
        record.workedHours = Math.round(((checkOut - checkIn) / 3600000) * 100) / 100;
        if (half) record.status = 'half-day';
      }
      records.push(record);
    });
  }
  await Attendance.insertMany(records);

  // ---- Leaves ----
  const leave = (user, leaveType, from, to, reason, extra = {}) => ({
    user: user._id,
    leaveType,
    fromDate: day(from),
    toDate: day(to),
    days: to - from + 1,
    reason,
    ...extra,
  });
  await Leave.insertMany([
    leave(priya, 'casual', 5, 6, 'Family function out of town'),
    leave(amit, 'sick', 1, 2, 'Fever and doctor advised rest'),
    leave(neha, 'earned', 10, 14, 'Planned vacation'),
    leave(karan, 'casual', -9, -9, 'Personal work', {
      status: 'approved', reviewedBy: manager._id, reviewNote: 'Approved', reviewedAt: day(-10),
    }),
    leave(priya, 'sick', -20, -19, 'Viral infection', {
      status: 'rejected', reviewedBy: manager._id, reviewNote: 'Sprint release week, please reschedule', reviewedAt: day(-21),
    }),
    leave(manager, 'casual', 20, 21, 'Attending a wedding'),
  ]);
  // keep balances in line with the approved leave above
  await User.updateOne({ _id: karan._id }, { $inc: { 'leaveBalance.casual': -1 } });

  // ---- Announcements ----
  await Announcement.insertMany([
    {
      title: 'Welcome to StaffSync', category: 'announcement', pinned: true, postedBy: hr._id,
      message: 'StaffSync is now our single place for attendance, leaves, news and training. Please mark your attendance every day and apply for leaves here.',
    },
    {
      title: 'Annual day celebration', category: 'event', postedBy: hr._id,
      message: 'Our annual day will be celebrated on the last Friday of this month. Cultural programme starts at 4 PM followed by dinner.',
    },
    {
      title: 'Updated work-from-home policy', category: 'policy', postedBy: hr._id,
      message: 'Employees may now work from home up to two days a week with manager approval. Details are available with the HR team.',
    },
    {
      title: 'Quarterly results are out', category: 'news', postedBy: hr._id,
      message: 'The company closed the quarter 18% above target. Thank you everyone for the great effort!',
    },
  ]);

  // ---- Trainings ----
  await Training.insertMany([
    {
      title: 'React Advanced Patterns', description: 'Hooks, performance and testing best practices.',
      trainer: 'Sandeep Rao', mode: 'online', startDate: day(3), endDate: day(5),
      assignedTo: [priya._id, amit._id], createdBy: manager._id,
    },
    {
      title: 'Secure Coding Basics', description: 'OWASP top 10 and how to avoid common mistakes.',
      trainer: 'Meera Iyer', mode: 'offline', startDate: day(-2), endDate: day(1),
      assignedTo: [priya._id, amit._id, neha._id, karan._id], completedBy: [neha._id], createdBy: manager._id,
    },
    {
      title: 'Effective Communication', description: 'Workshop on feedback and team communication.',
      trainer: 'Anita Sharma', mode: 'offline', startDate: day(-30), endDate: day(-29),
      assignedTo: [manager._id, priya._id], completedBy: [manager._id, priya._id], createdBy: hr._id,
    },
  ]);

  console.log('\nSeed finished. Demo logins:');
  console.log('  HR        hr@staffsync.com        Hr@12345');
  console.log('  Manager   manager@staffsync.com   Manager@123');
  console.log('  Employee  employee@staffsync.com  Employee@123');
  await mongoose.disconnect();
};

run().catch(async (err) => {
  console.error('Seed failed:', err);
  await mongoose.disconnect();
  process.exit(1);
});
