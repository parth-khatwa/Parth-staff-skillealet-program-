const express = require('express');
const Training = require('../models/Training');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { protect, authorize } = require('../middleware/auth');
const { parseDateOnly } = require('../utils/dates');
const { pick, fail } = require('../utils/helpers');

const router = express.Router();
router.use(protect);

const FIELDS = ['title', 'description', 'trainer', 'mode'];

const withPeople = (q) => q.populate('assignedTo', 'name department').populate('createdBy', 'name');

// Managers may only assign their own team. HR may assign any active person.
const checkAssignees = async (req, res, ids) => {
  if (!Array.isArray(ids)) fail(res, 400, 'assignedTo must be a list of employees');
  const unique = [...new Set(ids.map(String))];
  const filter = { _id: { $in: unique }, isActive: true };
  if (req.user.role === 'manager') filter.manager = req.user._id;
  const count = await User.countDocuments(filter);
  if (count !== unique.length) {
    fail(res, 403, req.user.role === 'manager' ? 'You can only assign your own team members' : 'Some selected employees are not valid');
  }
  return unique;
};

const readDates = (res, body) => {
  const startDate = parseDateOnly(body.startDate);
  const endDate = parseDateOnly(body.endDate);
  if (!startDate || !endDate) fail(res, 400, 'Valid start and end dates are required');
  if (endDate < startDate) fail(res, 400, 'End date cannot be before start date');
  return { startDate, endDate };
};

// HR can change any programme, a manager only the ones they created
const loadEditable = async (req, res) => {
  const training = await Training.findById(req.params.id);
  if (!training) fail(res, 404, 'Training not found');
  if (req.user.role !== 'hr' && String(training.createdBy) !== String(req.user._id)) {
    fail(res, 403, 'You can only change trainings you created');
  }
  return training;
};

// GET /api/trainings
router.get(
  '/',
  asyncHandler(async (req, res) => {
    let filter = { assignedTo: req.user._id };
    if (req.user.role === 'hr') filter = {};
    if (req.user.role === 'manager') filter = { $or: [{ createdBy: req.user._id }, { assignedTo: req.user._id }] };
    res.json(await withPeople(Training.find(filter).sort({ startDate: -1 })));
  })
);

// POST /api/trainings  - HR or manager
router.post(
  '/',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const dates = readDates(res, req.body);
    const assignedTo = await checkAssignees(req, res, req.body.assignedTo || []);
    const training = await Training.create({
      ...pick(req.body, FIELDS),
      ...dates,
      assignedTo,
      createdBy: req.user._id,
    });
    res.status(201).json(await withPeople(Training.findById(training._id)));
  })
);

// PUT /api/trainings/:id
router.put(
  '/:id',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const training = await loadEditable(req, res);
    Object.assign(training, pick(req.body, FIELDS));
    if (req.body.startDate || req.body.endDate) {
      Object.assign(training, readDates(res, { startDate: req.body.startDate, endDate: req.body.endDate }));
    }
    if (req.body.assignedTo) {
      training.assignedTo = await checkAssignees(req, res, req.body.assignedTo);
      training.completedBy = training.completedBy.filter((id) => training.assignedTo.map(String).includes(String(id)));
    }
    await training.save();
    res.json(await withPeople(Training.findById(training._id)));
  })
);

// PUT /api/trainings/:id/complete  - an assigned person marks it as completed
router.put(
  '/:id/complete',
  asyncHandler(async (req, res) => {
    const training = await Training.findOneAndUpdate(
      { _id: req.params.id, assignedTo: req.user._id },
      { $addToSet: { completedBy: req.user._id } },
      { new: true }
    );
    if (!training) fail(res, 404, 'Training not found or not assigned to you');
    res.json(await withPeople(Training.findById(training._id)));
  })
);

// DELETE /api/trainings/:id
router.delete(
  '/:id',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const training = await loadEditable(req, res);
    await training.deleteOne();
    res.json({ message: 'Training deleted' });
  })
);

module.exports = router;
