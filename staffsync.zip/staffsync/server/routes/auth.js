const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { protect } = require('../middleware/auth');
const { pick, fail } = require('../utils/helpers');

const router = express.Router();

const signToken = (id) =>
  jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d' });

// POST /api/auth/register  - public sign up (always creates an "employee")
router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) fail(res, 400, 'Name, email and password are required');
    if (password.length < 6) fail(res, 400, 'Password must be at least 6 characters');

    const user = await User.create({
      ...pick(req.body, ['name', 'email', 'password', 'department', 'designation', 'phone']),
      role: 'employee',
    });
    res.status(201).json({ token: signToken(user._id), user });
  })
);

// POST /api/auth/login
router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) fail(res, 400, 'Email and password are required');

    const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+password');
    if (!user || !(await user.matchPassword(password))) fail(res, 401, 'Invalid email or password');
    if (!user.isActive) fail(res, 403, 'Your account is deactivated. Contact HR.');

    res.json({ token: signToken(user._id), user });
  })
);

// GET /api/auth/me
router.get(
  '/me',
  protect,
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.user._id).populate('manager', 'name email');
    res.json(user);
  })
);

// PUT /api/auth/profile  - update own basic details
router.put(
  '/profile',
  protect,
  asyncHandler(async (req, res) => {
    const updates = pick(req.body, ['name', 'phone', 'address']);
    if (updates.name !== undefined && !String(updates.name).trim()) fail(res, 400, 'Name cannot be empty');
    Object.assign(req.user, updates);
    await req.user.save();
    const user = await User.findById(req.user._id).populate('manager', 'name email');
    res.json(user);
  })
);

// PUT /api/auth/password
router.put(
  '/password',
  protect,
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) fail(res, 400, 'Current and new password are required');
    if (newPassword.length < 6) fail(res, 400, 'New password must be at least 6 characters');

    const user = await User.findById(req.user._id).select('+password');
    if (!(await user.matchPassword(currentPassword))) fail(res, 400, 'Current password is incorrect');

    user.password = newPassword;
    await user.save();
    res.json({ message: 'Password updated successfully' });
  })
);

module.exports = router;
