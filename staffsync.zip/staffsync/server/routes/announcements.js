const express = require('express');
const Announcement = require('../models/Announcement');
const asyncHandler = require('../utils/asyncHandler');
const { protect, authorize } = require('../middleware/auth');
const { pick, fail } = require('../utils/helpers');

const router = express.Router();
router.use(protect);

const FIELDS = ['title', 'message', 'category', 'pinned'];

// GET /api/announcements?limit=  - everyone can read
router.get(
  '/',
  asyncHandler(async (req, res) => {
    let q = Announcement.find().populate('postedBy', 'name').sort({ pinned: -1, createdAt: -1 });
    const limit = parseInt(req.query.limit, 10);
    if (limit > 0) q = q.limit(Math.min(limit, 100));
    res.json(await q);
  })
);

// POST /api/announcements  - HR only
router.post(
  '/',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const item = await Announcement.create({ ...pick(req.body, FIELDS), postedBy: req.user._id });
    res.status(201).json(await item.populate('postedBy', 'name'));
  })
);

// PUT /api/announcements/:id
router.put(
  '/:id',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const item = await Announcement.findById(req.params.id);
    if (!item) fail(res, 404, 'Announcement not found');
    Object.assign(item, pick(req.body, FIELDS));
    await item.save();
    res.json(await item.populate('postedBy', 'name'));
  })
);

// DELETE /api/announcements/:id
router.delete(
  '/:id',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const item = await Announcement.findById(req.params.id);
    if (!item) fail(res, 404, 'Announcement not found');
    await item.deleteOne();
    res.json({ message: 'Announcement deleted' });
  })
);

module.exports = router;
