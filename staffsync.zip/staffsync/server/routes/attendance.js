const express = require('express');
const Attendance = require('../models/Attendance');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { protect, authorize } = require('../middleware/auth');
const { todayStr, monthStr, isDateStr, isMonthStr, minutesOfDayLocal } = require('../utils/dates');
const { fail } = require('../utils/helpers');

const router = express.Router();
router.use(protect);

const officeStartMinutes = () => {
  const [h, m] = (process.env.OFFICE_START || '09:30').split(':').map(Number);
  return h * 60 + (m || 0);
};

// GET /api/attendance/today  - my record for today (or null)
router.get(
  '/today',
  asyncHandler(async (req, res) => {
    res.json(await Attendance.findOne({ user: req.user._id, date: todayStr() }));
  })
);

// POST /api/attendance/check-in
router.post(
  '/check-in',
  asyncHandler(async (req, res) => {
    const date = todayStr();
    if (await Attendance.findOne({ user: req.user._id, date })) fail(res, 400, 'You have already checked in today');

    const now = new Date();
    const record = await Attendance.create({
      user: req.user._id,
      date,
      checkIn: now,
      status: minutesOfDayLocal(now) > officeStartMinutes() ? 'late' : 'present',
    });
    res.status(201).json(record);
  })
);

// POST /api/attendance/check-out
router.post(
  '/check-out',
  asyncHandler(async (req, res) => {
    const record = await Attendance.findOne({ user: req.user._id, date: todayStr() });
    if (!record) fail(res, 400, 'You have not checked in today');
    if (record.checkOut) fail(res, 400, 'You have already checked out today');

    record.checkOut = new Date();
    record.workedHours = Math.round(((record.checkOut - record.checkIn) / 3600000) * 100) / 100;
    if (record.workedHours < 4) record.status = 'half-day';
    await record.save();
    res.json(record);
  })
);

// GET /api/attendance/mine?month=YYYY-MM
router.get(
  '/mine',
  asyncHandler(async (req, res) => {
    const month = isMonthStr(req.query.month) ? req.query.month : monthStr();
    const records = await Attendance.find({ user: req.user._id, date: { $regex: `^${month}` } }).sort({ date: -1 });

    const summary = { present: 0, late: 0, halfDay: 0, totalHours: 0 };
    records.forEach((r) => {
      if (r.status === 'present') summary.present += 1;
      else if (r.status === 'late') summary.late += 1;
      else if (r.status === 'half-day') summary.halfDay += 1;
      summary.totalHours += r.workedHours || 0;
    });
    summary.totalHours = Math.round(summary.totalHours * 100) / 100;

    res.json({ month, records, summary });
  })
);

// GET /api/attendance?date=YYYY-MM-DD
// HR: all active people. Manager: only their team. Missing record = absent.
router.get(
  '/',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const date = isDateStr(req.query.date) ? req.query.date : todayStr();
    const userFilter = { isActive: true };
    if (req.user.role === 'manager') userFilter.manager = req.user._id;

    const users = await User.find(userFilter).select('name email department designation role').sort({ name: 1 });
    const records = await Attendance.find({ date, user: { $in: users.map((u) => u._id) } });
    const byUser = new Map(records.map((r) => [String(r.user), r]));

    res.json({
      date,
      rows: users.map((u) => {
        const record = byUser.get(String(u._id)) || null;
        return { user: u, record, status: record ? record.status : 'absent' };
      }),
    });
  })
);

module.exports = router;
