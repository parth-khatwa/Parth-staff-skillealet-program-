const express = require('express');
const Leave = require('../models/Leave');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
const { protect, authorize } = require('../middleware/auth');
const { parseDateOnly } = require('../utils/dates');
const { fail } = require('../utils/helpers');

const router = express.Router();
router.use(protect);

const TYPES = ['casual', 'sick', 'earned', 'unpaid'];
const populateUser = 'name email department designation role';

// POST /api/leaves  - apply for leave (any role)
router.post(
  '/',
  asyncHandler(async (req, res) => {
    const { leaveType, fromDate, toDate, reason } = req.body;
    if (!TYPES.includes(leaveType)) fail(res, 400, 'Invalid leave type');

    const from = parseDateOnly(fromDate);
    const to = parseDateOnly(toDate);
    if (!from || !to) fail(res, 400, 'Valid from and to dates are required');
    if (to < from) fail(res, 400, 'To date cannot be before from date');
    if (!reason || reason.trim().length < 3) fail(res, 400, 'Please give a reason for the leave');

    const days = Math.round((to - from) / 86400000) + 1;
    if (leaveType !== 'unpaid') {
      const left = req.user.leaveBalance[leaveType];
      if (left < days) fail(res, 400, `Not enough ${leaveType} leave balance (${left} day(s) left)`);
    }

    const overlap = await Leave.findOne({
      user: req.user._id,
      status: { $in: ['pending', 'approved'] },
      fromDate: { $lte: to },
      toDate: { $gte: from },
    });
    if (overlap) fail(res, 400, 'You already have a leave request for these dates');

    const leave = await Leave.create({
      user: req.user._id,
      leaveType,
      fromDate: from,
      toDate: to,
      days,
      reason: reason.trim(),
    });
    res.status(201).json(leave);
  })
);

// GET /api/leaves/mine
router.get(
  '/mine',
  asyncHandler(async (req, res) => {
    const leaves = await Leave.find({ user: req.user._id })
      .populate('reviewedBy', 'name')
      .sort({ createdAt: -1 });
    res.json(leaves);
  })
);

// GET /api/leaves?status=pending
// HR: everyone's requests. Manager: only their team's requests.
router.get(
  '/',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.user.role === 'manager') {
      const teamIds = await User.find({ manager: req.user._id }).distinct('_id');
      filter.user = { $in: teamIds };
    }
    const leaves = await Leave.find(filter)
      .populate('user', populateUser)
      .populate('reviewedBy', 'name')
      .sort({ createdAt: -1 });
    res.json(leaves);
  })
);

// PUT /api/leaves/:id/status  { status: 'approved' | 'rejected', note }
router.put(
  '/:id/status',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const { status, note } = req.body;
    if (!['approved', 'rejected'].includes(status)) fail(res, 400, 'Status must be approved or rejected');

    const leave = await Leave.findById(req.params.id).populate('user', `${populateUser} manager`);
    if (!leave) fail(res, 404, 'Leave request not found');
    if (leave.status !== 'pending') fail(res, 400, `This request is already ${leave.status}`);
    if (String(leave.user._id) === String(req.user._id)) fail(res, 403, 'You cannot review your own leave request');
    if (req.user.role === 'manager' && String(leave.user.manager) !== String(req.user._id)) {
      fail(res, 403, 'You can only review requests from your own team');
    }

    // Deduct from the balance when approving (atomic, never goes below zero)
    if (status === 'approved' && leave.leaveType !== 'unpaid') {
      const path = `leaveBalance.${leave.leaveType}`;
      const result = await User.updateOne(
        { _id: leave.user._id, [path]: { $gte: leave.days } },
        { $inc: { [path]: -leave.days } }
      );
      if (result.modifiedCount === 0) fail(res, 400, 'Employee does not have enough leave balance');
    }

    leave.status = status;
    leave.reviewedBy = req.user._id;
    leave.reviewNote = (note || '').trim();
    leave.reviewedAt = new Date();
    await leave.save();

    res.json(await Leave.findById(leave._id).populate('user', populateUser).populate('reviewedBy', 'name'));
  })
);

// DELETE /api/leaves/:id  - cancel your own pending request
router.delete(
  '/:id',
  asyncHandler(async (req, res) => {
    const leave = await Leave.findOne({ _id: req.params.id, user: req.user._id });
    if (!leave) fail(res, 404, 'Leave request not found');
    if (leave.status !== 'pending') fail(res, 400, 'Only pending requests can be cancelled');
    await leave.deleteOne();
    res.json({ message: 'Leave request cancelled' });
  })
);

module.exports = router;
