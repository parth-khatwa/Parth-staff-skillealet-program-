const express = require('express');
const User = require('../models/User');
const Leave = require('../models/Leave');
const Attendance = require('../models/Attendance');
const Training = require('../models/Training');
const asyncHandler = require('../utils/asyncHandler');
const { protect, authorize } = require('../middleware/auth');
const { pick, escapeRegex, fail } = require('../utils/helpers');

const router = express.Router();
router.use(protect);

const FIELDS = [
  'name', 'email', 'role', 'department', 'designation', 'phone', 'address',
  'salary', 'joiningDate', 'manager', 'isActive',
];

// The chosen manager must exist and really have the "manager" role
const checkManager = async (res, managerId) => {
  if (!managerId) return;
  const m = await User.findOne({ _id: managerId, role: 'manager' });
  if (!m) fail(res, 400, 'Selected manager is not valid');
};

// GET /api/employees?search=&role=&department=
// HR sees everyone. A manager sees only their own team (and no salaries).
router.get(
  '/',
  authorize('hr', 'manager'),
  asyncHandler(async (req, res) => {
    const filter = {};
    if (req.user.role === 'manager') filter.manager = req.user._id;
    if (req.query.role) filter.role = req.query.role;
    if (req.query.department) filter.department = req.query.department;
    if (req.query.search) {
      const rx = new RegExp(escapeRegex(req.query.search), 'i');
      filter.$or = [{ name: rx }, { email: rx }, { designation: rx }, { department: rx }];
    }

    let q = User.find(filter).populate('manager', 'name').sort({ name: 1 });
    if (req.user.role === 'manager') q = q.select('-salary');
    res.json(await q);
  })
);

// GET /api/employees/managers  - list of managers (for the "reports to" dropdown)
router.get(
  '/managers',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    res.json(await User.find({ role: 'manager', isActive: true }).select('name email department').sort({ name: 1 }));
  })
);

// POST /api/employees  - HR creates any kind of user
router.post(
  '/',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const data = pick(req.body, [...FIELDS, 'password']);
    if (!data.password || data.password.length < 6) fail(res, 400, 'Password (min 6 characters) is required');
    if (data.manager === '') data.manager = null;
    await checkManager(res, data.manager);

    const user = await User.create(data);
    res.status(201).json(user);
  })
);

// GET /api/employees/:id
router.get(
  '/:id',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id).populate('manager', 'name');
    if (!user) fail(res, 404, 'Employee not found');
    res.json(user);
  })
);

// PUT /api/employees/:id
router.put(
  '/:id',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    const user = await User.findById(req.params.id).select('+password');
    if (!user) fail(res, 404, 'Employee not found');

    const data = pick(req.body, FIELDS);
    if (data.manager === '') data.manager = null;
    if (data.manager) await checkManager(res, data.manager);
    if (data.manager && String(data.manager) === String(user._id)) fail(res, 400, 'A person cannot report to themselves');

    const isSelf = String(user._id) === String(req.user._id);
    if (isSelf && ((data.role && data.role !== 'hr') || data.isActive === false)) {
      fail(res, 400, 'You cannot change your own role or deactivate your own account');
    }

    Object.assign(user, data);
    if (req.body.password) {
      if (req.body.password.length < 6) fail(res, 400, 'Password must be at least 6 characters');
      user.password = req.body.password;
    }
    await user.save();
    res.json(await User.findById(user._id).populate('manager', 'name'));
  })
);

// DELETE /api/employees/:id  - removes the person and their leave/attendance records
router.delete(
  '/:id',
  authorize('hr'),
  asyncHandler(async (req, res) => {
    if (String(req.params.id) === String(req.user._id)) fail(res, 400, 'You cannot delete your own account');
    const user = await User.findById(req.params.id);
    if (!user) fail(res, 404, 'Employee not found');

    await Promise.all([
      Leave.deleteMany({ user: user._id }),
      Attendance.deleteMany({ user: user._id }),
      User.updateMany({ manager: user._id }, { manager: null }),
      Training.updateMany({}, { $pull: { assignedTo: user._id, completedBy: user._id } }),
    ]);
    await user.deleteOne();
    res.json({ message: 'Employee deleted' });
  })
);

module.exports = router;
