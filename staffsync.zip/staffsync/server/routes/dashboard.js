const express = require('express');
const User = require('../models/User');
const Leave = require('../models/Leave');
const Attendance = require('../models/Attendance');
const Training = require('../models/Training');
const asyncHandler = require('../utils/asyncHandler');
const { protect } = require('../middleware/auth');
const { todayStr, monthStr, parseDateOnly } = require('../utils/dates');

const router = express.Router();
router.use(protect);

// GET /api/dashboard  - numbers shown on the home page, depending on the role
router.get(
  '/',
  asyncHandler(async (req, res) => {
    const me = req.user;
    const today = todayStr();
    const todayDate = parseDateOnly(today);

    // Same for everybody: my own balance and today's attendance
    const todayRecord = await Attendance.findOne({ user: me._id, date: today });
    const base = { role: me.role, leaveBalance: me.leaveBalance, todayRecord };

    if (me.role === 'hr') {
      const [totalEmployees, presentToday, pendingLeaves, onLeaveToday, activeTrainings, departments] =
        await Promise.all([
          User.countDocuments({ isActive: true }),
          Attendance.countDocuments({ date: today }),
          Leave.countDocuments({ status: 'pending' }),
          Leave.countDocuments({ status: 'approved', fromDate: { $lte: todayDate }, toDate: { $gte: todayDate } }),
          Training.countDocuments({ endDate: { $gte: todayDate } }),
          User.aggregate([
            { $match: { isActive: true } },
            { $group: { _id: '$department', count: { $sum: 1 } } },
            { $sort: { count: -1 } },
          ]),
        ]);
      return res.json({
        ...base,
        stats: { totalEmployees, presentToday, pendingLeaves, onLeaveToday, activeTrainings },
        departments,
      });
    }

    if (me.role === 'manager') {
      const teamIds = await User.find({ manager: me._id, isActive: true }).distinct('_id');
      const [presentToday, pendingLeaves, activeTrainings] = await Promise.all([
        Attendance.countDocuments({ date: today, user: { $in: teamIds } }),
        Leave.countDocuments({ status: 'pending', user: { $in: teamIds } }),
        Training.countDocuments({ createdBy: me._id, endDate: { $gte: todayDate } }),
      ]);
      return res.json({
        ...base,
        stats: { teamSize: teamIds.length, presentToday, pendingLeaves, activeTrainings },
      });
    }

    const [presentDays, pendingLeaves, pendingTrainings] = await Promise.all([
      Attendance.countDocuments({ user: me._id, date: { $regex: `^${monthStr()}` } }),
      Leave.countDocuments({ user: me._id, status: 'pending' }),
      Training.countDocuments({ assignedTo: me._id, completedBy: { $ne: me._id } }),
    ]);
    res.json({ ...base, stats: { presentDays, pendingLeaves, pendingTrainings } });
  })
);

module.exports = router;
