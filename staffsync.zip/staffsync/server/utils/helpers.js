// Small shared helpers for the route files.

// Return a new object holding only the listed keys that exist on `obj`.
const pick = (obj = {}, keys = []) =>
  keys.reduce((acc, k) => {
    if (obj[k] !== undefined) acc[k] = obj[k];
    return acc;
  }, {});

// Escape user text before putting it in a RegExp.
const escapeRegex = (s = '') => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

// Throw an error that the error middleware turns into the given HTTP status.
const fail = (res, status, message) => {
  res.status(status);
  throw new Error(message);
};

module.exports = { pick, escapeRegex, fail };
