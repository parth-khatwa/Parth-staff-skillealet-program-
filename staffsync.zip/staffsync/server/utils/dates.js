// Date helpers. Attendance days are stored as "YYYY-MM-DD" strings in the
// company's local time (TZ_OFFSET_MINUTES, default 330 = India Standard Time),
// so the "day" is correct even when the server itself runs in UTC.

const offsetMinutes = () => Number(process.env.TZ_OFFSET_MINUTES || 330);

const localNow = () => new Date(Date.now() + offsetMinutes() * 60000);

const todayStr = () => localNow().toISOString().slice(0, 10);

const monthStr = () => todayStr().slice(0, 7);

const isDateStr = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s || '') && !isNaN(new Date(`${s}T00:00:00Z`));

const isMonthStr = (s) => /^\d{4}-\d{2}$/.test(s || '');

// "YYYY-MM-DD" + n days -> "YYYY-MM-DD"
const addDays = (dateStr, n) => {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

// Local date + "HH:MM" -> real Date (UTC instant)
const atLocal = (dateStr, hhmm) =>
  new Date(Date.parse(`${dateStr}T${hhmm}:00Z`) - offsetMinutes() * 60000);

// Minutes since local midnight for a given instant
const minutesOfDayLocal = (date = new Date()) => {
  const l = new Date(date.getTime() + offsetMinutes() * 60000);
  return l.getUTCHours() * 60 + l.getUTCMinutes();
};

// "YYYY-MM-DD" -> Date at UTC midnight (null if invalid)
const parseDateOnly = (s) => (isDateStr(s) ? new Date(`${s}T00:00:00Z`) : null);

module.exports = {
  todayStr,
  monthStr,
  isDateStr,
  isMonthStr,
  addDays,
  atLocal,
  minutesOfDayLocal,
  parseDateOnly,
};
