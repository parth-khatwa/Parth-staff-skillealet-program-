# StaffSync — Modern Human Resource Management Solution

StaffSync is a web-based HRM application built with the **MERN stack** (MongoDB, Express.js, React.js, Node.js).
It digitises the core HR processes of a company and gives **HR**, **managers** and **employees** their own
role-based views.

## Features

| Role | What they can do |
| --- | --- |
| **HR** | Add / edit / delete employee records, assign managers, approve or reject any leave request, view attendance of everyone, post and pin news & announcements, create training programmes |
| **Manager** | See own team, approve or reject team leave requests, view team attendance, create trainings and assign them to team members |
| **Employee** | Check in / check out (late and half-day detection), apply for leave and track status, see leave balance, read announcements, complete assigned trainings, edit personal profile, change password |

Also included: JWT authentication, password hashing (bcrypt), protected routes on both frontend and backend,
role-based API authorization, a role-aware dashboard, responsive Bootstrap 5 UI.

## Tech stack

- **Frontend:** React 18 (Vite), React Router 6, Axios, Bootstrap 5, Bootstrap Icons
- **Backend:** Node.js, Express 4, async/await, REST API
- **Database:** MongoDB with Mongoose
- **Auth:** JSON Web Tokens (JWT) + bcryptjs
- **Security:** helmet, CORS, server-side validation

## Project structure

```
staffsync/
├── server/                  # Express + MongoDB API
│   ├── config/db.js
│   ├── middleware/          # auth (JWT + roles), error handling
│   ├── models/              # User, Leave, Attendance, Announcement, Training
│   ├── routes/              # auth, employees, leaves, attendance, announcements, trainings, dashboard
│   ├── utils/
│   ├── seed.js              # demo data
│   ├── server.js
│   └── .env.example
├── client/                  # React app (Vite)
│   └── src/
│       ├── components/      # Layout, ProtectedRoute, shared UI
│       ├── context/         # Auth + Toast providers
│       ├── pages/           # Login, Register, Dashboard, Attendance, Leaves, ...
│       └── api.js
└── package.json             # helper scripts
```

## Requirements

- Node.js **v16 or above** and npm v8+
- MongoDB (local install **or** a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster)
- Git, and optionally Postman for testing the API

## Getting started

```bash
# 1. install everything
npm run install-all

# 2. configure the server
cp server/.env.example server/.env
#    then open server/.env and set MONGO_URI and a long random JWT_SECRET

# 3. (optional but recommended) load demo data
npm run seed

# 4. run the API (http://localhost:5000) ...
npm run server

# 5. ... and in a second terminal, the React app (http://localhost:5173)
npm run client
```

In development the Vite dev server proxies `/api` to `http://localhost:5000`, so no extra frontend config is needed.

### Demo accounts (created by `npm run seed`)

| Role | Email | Password |
| --- | --- | --- |
| HR | `hr@staffsync.com` | `Hr@12345` |
| Manager | `manager@staffsync.com` | `Manager@123` |
| Employee | `employee@staffsync.com` | `Employee@123` |

> `npm run seed` **deletes** existing users, leaves, attendance, announcements and trainings before inserting demo data.
> Change or remove these accounts before using the app for anything real.

## Environment variables (`server/.env`)

| Variable | Description | Default |
| --- | --- | --- |
| `PORT` | API port | `5000` |
| `MONGO_URI` | MongoDB connection string | `mongodb://127.0.0.1:27017/staffsync` |
| `JWT_SECRET` | Secret used to sign tokens (**required**) | — |
| `JWT_EXPIRES_IN` | Token lifetime | `7d` |
| `CLIENT_URL` | Allowed frontend origin(s), comma separated | any (dev) |
| `TZ_OFFSET_MINUTES` | Company timezone offset from UTC in minutes (India = 330) | `330` |
| `OFFICE_START` | Check-ins after this local time are marked *late* | `09:30` |

Frontend (`client/.env`, only when hosted separately): `VITE_API_URL=https://your-api.example.com/api`

## API overview

All routes except `/api/auth/register` and `/api/auth/login` need the header `Authorization: Bearer <token>`.

| Method & path | Access | Purpose |
| --- | --- | --- |
| `POST /api/auth/register` | public | Sign up (creates an *employee*) |
| `POST /api/auth/login` | public | Log in, returns JWT |
| `GET /api/auth/me` | all | Current user |
| `PUT /api/auth/profile` · `PUT /api/auth/password` | all | Update profile / change password |
| `GET /api/dashboard` | all | Role-specific statistics |
| `GET /api/employees` | HR, manager | List (manager sees own team only, no salaries) |
| `POST/PUT/DELETE /api/employees[/:id]` | HR | Manage employees |
| `GET /api/employees/managers` | HR | Managers for the "reports to" dropdown |
| `POST /api/attendance/check-in` · `/check-out` | all | Mark attendance |
| `GET /api/attendance/today` · `/mine?month=YYYY-MM` | all | Own attendance |
| `GET /api/attendance?date=YYYY-MM-DD` | HR, manager | Attendance sheet (absent = no record) |
| `POST /api/leaves` · `GET /api/leaves/mine` · `DELETE /api/leaves/:id` | all | Apply / list / cancel own leave |
| `GET /api/leaves?status=` | HR, manager | Requests to review |
| `PUT /api/leaves/:id/status` | HR, manager | Approve / reject |
| `GET /api/announcements` | all | Read news |
| `POST/PUT/DELETE /api/announcements[/:id]` | HR | Manage news |
| `GET /api/trainings` | all | Role-filtered list |
| `POST/PUT/DELETE /api/trainings[/:id]` | HR, manager | Manage trainings |
| `PUT /api/trainings/:id/complete` | assigned person | Mark completed |

## Business rules worth knowing

- Leave balance (casual 12, sick 10, earned 15) is checked when applying and **deducted on approval**. Unpaid leave has no balance.
- Leave days are counted as calendar days from the *from* date to the *to* date, inclusive.
- Nobody can approve their own leave. A manager's leave is approved by HR; HR's own leave needs a second HR account.
- A manager can only review leaves of, and assign trainings to, people who report to them.
- A check-in after `OFFICE_START` is *late*; fewer than 4 worked hours becomes *half-day*; no record = *absent*.
- Salary is visible only to HR and to the employee themself.

## Deployment

**Option A — one service (simplest, e.g. Render / Railway):**

1. Create a MongoDB Atlas cluster and copy its connection string.
2. Create a Web Service from this GitHub repo.
   - Build command: `npm run build`
   - Start command: `npm start`
   - Environment: `NODE_ENV=production`, `MONGO_URI`, `JWT_SECRET`, `TZ_OFFSET_MINUTES`
3. The Express server also serves the built React app, so the service URL is your **demo link**.

**Option B — split:** deploy `server/` to Render/Railway and `client/` to Vercel/Netlify
(build `npm run build`, output `dist`, env `VITE_API_URL=https://<api-host>/api`, and set `CLIENT_URL` on the API to the frontend URL).
Add a rewrite of all paths to `/index.html` on the frontend host so page refreshes work.

To load demo data into a hosted database, run `npm run seed` locally with `MONGO_URI` in `server/.env` pointing to Atlas.

## Pushing to GitHub

```bash
cd staffsync
git init
git add .
git commit -m "StaffSync: MERN human resource management system"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

`.gitignore` already excludes `node_modules` and `.env`, so no secrets are uploaded.

## Possible next steps

Payroll and payslips, document uploads, department / holiday calendar, email notifications, export to CSV/PDF, automated tests.

## License

MIT
