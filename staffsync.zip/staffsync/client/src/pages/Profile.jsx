import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, StatusBadge } from '../components/ui';
import { fmtDate, roleLabel } from '../utils';

export default function Profile() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [info, setInfo] = useState({ name: user.name, phone: user.phone || '', address: user.address || '' });
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [busy, setBusy] = useState('');

  useEffect(() => {
    setInfo({ name: user.name, phone: user.phone || '', address: user.address || '' });
  }, [user]);

  const saveInfo = async (e) => {
    e.preventDefault();
    setBusy('info');
    try {
      const { data } = await api.put('/auth/profile', info);
      setUser(data);
      toast.success('Profile updated');
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy('');
    }
  };

  const savePassword = async (e) => {
    e.preventDefault();
    if (pw.newPassword !== pw.confirm) return toast.error('New passwords do not match');
    setBusy('pw');
    try {
      await api.put('/auth/password', { currentPassword: pw.currentPassword, newPassword: pw.newPassword });
      toast.success('Password changed');
      setPw({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy('');
    }
  };

  const rows = [
    ['Email', user.email],
    ['Role', <StatusBadge key="r" value={user.role} label={roleLabel[user.role]} />],
    ['Department', user.department],
    ['Designation', user.designation],
    ['Reports to', user.manager?.name || '—'],
    ['Joined on', fmtDate(user.joiningDate)],
    ['Monthly salary', `₹${(user.salary || 0).toLocaleString('en-IN')}`],
  ];

  return (
    <>
      <PageHeader title="My Profile" subtitle="Keep your personal details up to date" />

      <div className="row g-3">
        <div className="col-lg-5">
          <div className="card h-100">
            <div className="card-body">
              <div className="d-flex align-items-center gap-3 mb-3">
                <span className="avatar" style={{ width: 56, height: 56, fontSize: '1.4rem' }}>{user.name.charAt(0).toUpperCase()}</span>
                <div>
                  <div className="fs-5 fw-semibold">{user.name}</div>
                  <div className="text-muted">{user.designation}</div>
                </div>
              </div>
              <dl className="row mb-0">
                {rows.map(([k, v]) => (
                  <div className="d-contents" key={k}>
                    <dt className="col-5 text-muted fw-normal py-1">{k}</dt>
                    <dd className="col-7 py-1 mb-0">{v}</dd>
                  </div>
                ))}
              </dl>
              <div className="small text-muted mt-3">Department, role and salary can only be changed by HR.</div>
            </div>
          </div>
        </div>

        <div className="col-lg-7">
          <div className="card mb-3">
            <div className="card-header">Personal details</div>
            <form className="card-body" onSubmit={saveInfo}>
              <div className="row g-3">
                <div className="col-md-6">
                  <label className="form-label">Full name</label>
                  <input className="form-control" value={info.name} onChange={(e) => setInfo({ ...info, name: e.target.value })} required />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Phone</label>
                  <input className="form-control" value={info.phone} onChange={(e) => setInfo({ ...info, phone: e.target.value })} />
                </div>
                <div className="col-12">
                  <label className="form-label">Address</label>
                  <textarea className="form-control" rows={2} value={info.address} onChange={(e) => setInfo({ ...info, address: e.target.value })} />
                </div>
              </div>
              <button className="btn btn-primary mt-3" disabled={busy === 'info'}>
                {busy === 'info' && <span className="spinner-border spinner-border-sm me-2" />}Save details
              </button>
            </form>
          </div>

          <div className="card">
            <div className="card-header">Change password</div>
            <form className="card-body" onSubmit={savePassword}>
              <div className="row g-3">
                <div className="col-12">
                  <label className="form-label">Current password</label>
                  <input type="password" className="form-control" value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} required />
                </div>
                <div className="col-md-6">
                  <label className="form-label">New password</label>
                  <input type="password" className="form-control" minLength={6} value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} required />
                </div>
                <div className="col-md-6">
                  <label className="form-label">Confirm new password</label>
                  <input type="password" className="form-control" minLength={6} value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} required />
                </div>
              </div>
              <button className="btn btn-dark mt-3" disabled={busy === 'pw'}>
                {busy === 'pw' && <span className="spinner-border spinner-border-sm me-2" />}Update password
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
