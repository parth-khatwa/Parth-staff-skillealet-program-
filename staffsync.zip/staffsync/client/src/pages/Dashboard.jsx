import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Empty, Loader, PageHeader, StatCard, StatusBadge } from '../components/ui';
import { fmtDate, fmtTime } from '../utils';

export default function Dashboard() {
  const { user } = useAuth();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [news, setNews] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const [d, a] = await Promise.all([api.get('/dashboard'), api.get('/announcements?limit=4')]);
        setData(d.data);
        setNews(a.data);
      } catch (e) {
        toast.error(errMsg(e));
      }
    })();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  if (!data) return <Loader />;

  const s = data.stats;
  const today = data.todayRecord;

  const cards = {
    hr: [
      ['people', 'Total employees', s.totalEmployees, 'primary'],
      ['person-check', 'Present today', s.presentToday, 'success'],
      ['airplane', 'On leave today', s.onLeaveToday, 'warning'],
      ['inbox', 'Pending leave requests', s.pendingLeaves, 'danger'],
    ],
    manager: [
      ['people', 'Team size', s.teamSize, 'primary'],
      ['person-check', 'Team present today', s.presentToday, 'success'],
      ['inbox', 'Pending team leaves', s.pendingLeaves, 'danger'],
      ['mortarboard', 'Active trainings', s.activeTrainings, 'info'],
    ],
    employee: [
      ['calendar-check', 'Days present this month', s.presentDays, 'success'],
      ['hourglass-split', 'My pending leaves', s.pendingLeaves, 'warning'],
      ['mortarboard', 'Trainings to complete', s.pendingTrainings, 'info'],
    ],
  }[user.role];

  const maxDept = Math.max(1, ...(data.departments || []).map((d) => d.count));

  return (
    <>
      <PageHeader title={`Hello, ${user.name.split(' ')[0]} 👋`} subtitle={`${user.designation} · ${user.department}`} />

      <div className="row g-3 mb-4">
        {cards.map(([icon, label, value, color]) => (
          <StatCard key={label} icon={icon} label={label} value={value} color={color} />
        ))}
        {/* Today's attendance tile */}
        <div className="col-6 col-xl-3">
          <Link to="/attendance" className="text-decoration-none">
            <div className="card stat-card h-100">
              <div className="card-body d-flex align-items-center gap-3">
                <span className="stat-icon bg-primary-subtle text-primary"><i className="bi bi-clock" /></span>
                <div>
                  <div className="text-muted small">My attendance today</div>
                  {today ? (
                    <div className="mt-1"><StatusBadge value={today.status} /> <small className="text-muted ms-1">in {fmtTime(today.checkIn)}</small></div>
                  ) : (
                    <div className="fw-semibold mt-1 text-danger">Not checked in</div>
                  )}
                </div>
              </div>
            </div>
          </Link>
        </div>
      </div>

      <div className="row g-3">
        <div className="col-lg-7">
          <div className="card h-100">
            <div className="card-header d-flex justify-content-between align-items-center">
              Latest announcements
              <Link to="/announcements" className="small fw-normal">View all</Link>
            </div>
            <div className="list-group list-group-flush">
              {news.length === 0 && <Empty icon="megaphone" text="No announcements yet" />}
              {news.map((n) => (
                <div key={n._id} className="list-group-item py-3">
                  <div className="d-flex justify-content-between gap-2">
                    <div className="fw-medium">
                      {n.pinned && <i className="bi bi-pin-angle-fill pin me-1" />}
                      {n.title}
                    </div>
                    <StatusBadge value={n.category} />
                  </div>
                  <div className="text-muted small mt-1 text-truncate">{n.message}</div>
                  <div className="text-muted small mt-1">{fmtDate(n.createdAt)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="col-lg-5">
          <div className="card mb-3">
            <div className="card-header">My leave balance</div>
            <div className="card-body">
              <div className="row g-2 text-center">
                {Object.entries(data.leaveBalance).map(([type, days]) => (
                  <div className="col-4" key={type}>
                    <div className="balance-ring">
                      <div className="fs-3 fw-semibold text-primary">{days}</div>
                      <div className="small text-muted text-capitalize">{type}</div>
                    </div>
                  </div>
                ))}
              </div>
              <Link to="/leaves" className="btn btn-outline-primary btn-sm mt-3">Apply for leave</Link>
            </div>
          </div>

          {user.role === 'hr' && (
            <div className="card">
              <div className="card-header">Employees by department</div>
              <div className="card-body">
                {data.departments.map((d) => (
                  <div key={d._id} className="mb-3">
                    <div className="d-flex justify-content-between small mb-1">
                      <span>{d._id || 'Unassigned'}</span>
                      <span className="text-muted">{d.count}</span>
                    </div>
                    <div className="progress" style={{ height: 8 }}>
                      <div className="progress-bar" style={{ width: `${(d.count / maxDept) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
