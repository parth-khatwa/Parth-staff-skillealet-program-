import { useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api';
import { AuthHero } from './Login';

export default function Register() {
  const { user, register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.password !== form.confirm) return setError('Passwords do not match');
    setBusy(true);
    try {
      await register({ name: form.name, email: form.email, password: form.password });
      navigate('/', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <AuthHero />
      <div className="auth-form">
        <div style={{ width: '100%', maxWidth: 400 }}>
          <h3 className="fw-semibold mb-1">Create your account</h3>
          <p className="text-muted mb-4">Employee sign up. HR can change your role and department later.</p>

          {error && <div className="alert alert-danger py-2">{error}</div>}

          <form onSubmit={submit}>
            <div className="mb-3">
              <label className="form-label">Full name</label>
              <input className="form-control" value={form.name} onChange={set('name')} required autoFocus />
            </div>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input type="email" className="form-control" value={form.email} onChange={set('email')} required />
            </div>
            <div className="mb-3">
              <label className="form-label">Password</label>
              <input type="password" className="form-control" value={form.password} onChange={set('password')} minLength={6} required />
            </div>
            <div className="mb-4">
              <label className="form-label">Confirm password</label>
              <input type="password" className="form-control" value={form.confirm} onChange={set('confirm')} minLength={6} required />
            </div>
            <button className="btn btn-primary w-100" disabled={busy}>
              {busy && <span className="spinner-border spinner-border-sm me-2" />}
              Create account
            </button>
          </form>

          <p className="text-center text-muted mt-3">
            Already have an account? <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
