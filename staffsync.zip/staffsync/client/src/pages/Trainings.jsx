import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ConfirmModal, Empty, Loader, Modal, PageHeader, StatusBadge } from '../components/ui';
import { fmtDate, todayISO, toInputDate } from '../utils';

const emptyForm = () => ({
  title: '', description: '', trainer: '', mode: 'online', startDate: todayISO(), endDate: todayISO(), assignedTo: [],
});

export default function Trainings() {
  const { user } = useAuth();
  const toast = useToast();
  const canManage = user.role === 'hr' || user.role === 'manager';

  const [items, setItems] = useState(null);
  const [people, setPeople] = useState([]);
  const [editing, setEditing] = useState(null); // null | 'new' | training
  const [form, setForm] = useState(emptyForm());
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const calls = [api.get('/trainings')];
      if (canManage) calls.push(api.get('/employees'));
      const [t, e] = await Promise.all(calls);
      setItems(t.data);
      if (e) setPeople(e.data.filter((p) => p.isActive && p._id !== user._id));
    } catch (err) {
      toast.error(errMsg(err));
    }
  }, [canManage, user._id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const openNew = () => {
    setForm(emptyForm());
    setEditing('new');
  };
  const openEdit = (t) => {
    setForm({
      title: t.title, description: t.description || '', trainer: t.trainer || '', mode: t.mode,
      startDate: toInputDate(t.startDate), endDate: toInputDate(t.endDate),
      assignedTo: t.assignedTo.map((p) => p._id),
    });
    setEditing(t);
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const toggle = (id) =>
    setForm((f) => ({
      ...f,
      assignedTo: f.assignedTo.includes(id) ? f.assignedTo.filter((x) => x !== id) : [...f.assignedTo, id],
    }));

  const allSelected = people.length > 0 && people.every((p) => form.assignedTo.includes(p._id));
  const toggleAll = () => setForm((f) => ({ ...f, assignedTo: allSelected ? [] : people.map((p) => p._id) }));

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (editing === 'new') await api.post('/trainings', form);
      else await api.put(`/trainings/${editing._id}`, form);
      toast.success(editing === 'new' ? 'Training created' : 'Training updated');
      setEditing(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const complete = async (t) => {
    try {
      await api.put(`/trainings/${t._id}/complete`);
      toast.success('Marked as completed. Well done!');
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await api.delete(`/trainings/${deleting._id}`);
      toast.success('Training deleted');
      setDeleting(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader
        title="Training & Development"
        subtitle={canManage ? 'Plan programmes and assign them to people' : 'Programmes assigned to you'}
      >
        {canManage && (
          <button className="btn btn-primary" onClick={openNew}>
            <i className="bi bi-plus-lg me-2" />New training
          </button>
        )}
      </PageHeader>

      {!items ? (
        <Loader />
      ) : items.length === 0 ? (
        <div className="card"><Empty icon="mortarboard" text="No training programmes yet" /></div>
      ) : (
        <div className="row g-3">
          {items.map((t) => {
            const assigned = t.assignedTo.some((p) => p._id === user._id);
            const done = t.completedBy.includes(user._id);
            const mine = t.createdBy?._id === user._id || user.role === 'hr';
            return (
              <div className="col-md-6 col-xl-4" key={t._id}>
                <div className="card h-100">
                  <div className="card-body d-flex flex-column">
                    <div className="d-flex justify-content-between align-items-start gap-2 mb-2">
                      <h5 className="mb-0">{t.title}</h5>
                      <StatusBadge value={t.status} />
                    </div>
                    {t.description && <p className="text-muted small mb-2">{t.description}</p>}
                    <ul className="list-unstyled small mb-3">
                      <li><i className="bi bi-calendar-event me-2" />{fmtDate(t.startDate)} – {fmtDate(t.endDate)}</li>
                      <li><i className="bi bi-person-video3 me-2" />{t.trainer || 'Trainer to be announced'}</li>
                      <li><i className={`bi bi-${t.mode === 'online' ? 'laptop' : 'geo-alt'} me-2`} />{t.mode === 'online' ? 'Online' : 'In person'}</li>
                      <li>
                        <i className="bi bi-people me-2" />
                        {t.assignedTo.length} assigned · {t.completedBy.length} completed
                      </li>
                    </ul>

                    <div className="mt-auto d-flex flex-wrap gap-2 align-items-center">
                      {assigned && !done && (
                        <button className="btn btn-sm btn-success" onClick={() => complete(t)}>
                          <i className="bi bi-check2-circle me-1" />Mark completed
                        </button>
                      )}
                      {assigned && done && <span className="text-success small"><i className="bi bi-patch-check-fill me-1" />You completed this</span>}
                      {canManage && mine && (
                        <span className="ms-auto">
                          <button className="btn btn-sm btn-outline-primary me-1" onClick={() => openEdit(t)}><i className="bi bi-pencil" /></button>
                          <button className="btn btn-sm btn-outline-danger" onClick={() => setDeleting(t)}><i className="bi bi-trash" /></button>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {editing && (
        <Modal
          title={editing === 'new' ? 'New training' : 'Edit training'}
          onClose={() => setEditing(null)}
          onSubmit={save}
          submitLabel={editing === 'new' ? 'Create' : 'Save changes'}
          busy={busy}
          size="lg"
        >
          <div className="row g-3">
            <div className="col-12">
              <label className="form-label">Title *</label>
              <input className="form-control" value={form.title} onChange={set('title')} maxLength={120} required />
            </div>
            <div className="col-12">
              <label className="form-label">Description</label>
              <textarea className="form-control" rows={2} value={form.description} onChange={set('description')} maxLength={1000} />
            </div>
            <div className="col-md-6">
              <label className="form-label">Trainer</label>
              <input className="form-control" value={form.trainer} onChange={set('trainer')} />
            </div>
            <div className="col-md-6">
              <label className="form-label">Mode</label>
              <select className="form-select" value={form.mode} onChange={set('mode')}>
                <option value="online">Online</option>
                <option value="offline">In person</option>
              </select>
            </div>
            <div className="col-md-6">
              <label className="form-label">Start date *</label>
              <input type="date" className="form-control" value={form.startDate} onChange={set('startDate')} required />
            </div>
            <div className="col-md-6">
              <label className="form-label">End date *</label>
              <input type="date" className="form-control" value={form.endDate} min={form.startDate} onChange={set('endDate')} required />
            </div>
            <div className="col-12">
              <div className="d-flex justify-content-between align-items-center mb-1">
                <label className="form-label mb-0">Assign to ({form.assignedTo.length} selected)</label>
                {people.length > 0 && (
                  <button type="button" className="btn btn-link btn-sm p-0" onClick={toggleAll}>
                    {allSelected ? 'Clear all' : 'Select all'}
                  </button>
                )}
              </div>
              <div className="border rounded-3 p-2" style={{ maxHeight: 180, overflowY: 'auto' }}>
                {people.length === 0 && <div className="text-muted small p-2">No people available to assign.</div>}
                {people.map((p) => (
                  <div className="form-check" key={p._id}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={`p-${p._id}`}
                      checked={form.assignedTo.includes(p._id)}
                      onChange={() => toggle(p._id)}
                    />
                    <label className="form-check-label" htmlFor={`p-${p._id}`}>
                      {p.name} <small className="text-muted">· {p.department}</small>
                    </label>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Modal>
      )}

      {deleting && (
        <ConfirmModal
          title="Delete training"
          message={`Delete "${deleting.title}"?`}
          busy={busy}
          onConfirm={remove}
          onClose={() => setDeleting(null)}
        />
      )}
    </>
  );
}
