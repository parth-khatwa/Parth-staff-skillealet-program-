import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ConfirmModal, Empty, Loader, Modal, PageHeader, StatusBadge } from '../components/ui';
import { fmtStamp } from '../utils';

const emptyForm = { title: '', message: '', category: 'announcement', pinned: false };

export default function Announcements() {
  const { user } = useAuth();
  const toast = useToast();
  const isHR = user.role === 'hr';

  const [items, setItems] = useState(null);
  const [editing, setEditing] = useState(null); // null | 'new' | item
  const [form, setForm] = useState(emptyForm);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      setItems((await api.get('/announcements')).data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const openNew = () => {
    setForm(emptyForm);
    setEditing('new');
  };
  const openEdit = (a) => {
    setForm({ title: a.title, message: a.message, category: a.category, pinned: a.pinned });
    setEditing(a);
  };
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      if (editing === 'new') await api.post('/announcements', form);
      else await api.put(`/announcements/${editing._id}`, form);
      toast.success(editing === 'new' ? 'Announcement posted' : 'Announcement updated');
      setEditing(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await api.delete(`/announcements/${deleting._id}`);
      toast.success('Announcement deleted');
      setDeleting(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader title="News & Announcements" subtitle="Stay updated with what is happening in the company">
        {isHR && (
          <button className="btn btn-primary" onClick={openNew}>
            <i className="bi bi-plus-lg me-2" />New post
          </button>
        )}
      </PageHeader>

      {!items ? (
        <Loader />
      ) : items.length === 0 ? (
        <div className="card"><Empty icon="megaphone" text="No announcements yet" /></div>
      ) : (
        <div className="row g-3">
          {items.map((a) => (
            <div className="col-12" key={a._id}>
              <div className="card">
                <div className="card-body">
                  <div className="d-flex flex-wrap justify-content-between gap-2">
                    <h5 className="mb-1">
                      {a.pinned && <i className="bi bi-pin-angle-fill pin me-2" title="Pinned" />}
                      {a.title}
                    </h5>
                    <div className="d-flex align-items-center gap-2">
                      <StatusBadge value={a.category} />
                      {isHR && (
                        <>
                          <button className="btn btn-sm btn-outline-primary" onClick={() => openEdit(a)}><i className="bi bi-pencil" /></button>
                          <button className="btn btn-sm btn-outline-danger" onClick={() => setDeleting(a)}><i className="bi bi-trash" /></button>
                        </>
                      )}
                    </div>
                  </div>
                  <p className="mb-2 mt-2" style={{ whiteSpace: 'pre-wrap' }}>{a.message}</p>
                  <small className="text-muted">Posted by {a.postedBy?.name || 'HR'} · {fmtStamp(a.createdAt)}</small>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <Modal
          title={editing === 'new' ? 'New announcement' : 'Edit announcement'}
          onClose={() => setEditing(null)}
          onSubmit={save}
          submitLabel={editing === 'new' ? 'Post' : 'Save changes'}
          busy={busy}
        >
          <div className="mb-3">
            <label className="form-label">Title</label>
            <input className="form-control" value={form.title} onChange={set('title')} maxLength={120} required />
          </div>
          <div className="mb-3">
            <label className="form-label">Category</label>
            <select className="form-select" value={form.category} onChange={set('category')}>
              <option value="announcement">Announcement</option>
              <option value="news">News</option>
              <option value="policy">Policy</option>
              <option value="event">Event</option>
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label">Message</label>
            <textarea className="form-control" rows={5} value={form.message} onChange={set('message')} maxLength={2000} required />
          </div>
          <div className="form-check">
            <input className="form-check-input" type="checkbox" id="pinned" checked={form.pinned} onChange={set('pinned')} />
            <label className="form-check-label" htmlFor="pinned">Pin to the top</label>
          </div>
        </Modal>
      )}

      {deleting && (
        <ConfirmModal
          title="Delete announcement"
          message={`Delete "${deleting.title}"?`}
          busy={busy}
          onConfirm={remove}
          onClose={() => setDeleting(null)}
        />
      )}
    </>
  );
}
