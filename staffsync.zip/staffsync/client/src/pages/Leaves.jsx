import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ConfirmModal, Empty, Loader, Modal, PageHeader, StatusBadge } from '../components/ui';
import { capitalize, fmtDate, todayISO } from '../utils';

const emptyForm = () => ({ leaveType: 'casual', fromDate: todayISO(), toDate: todayISO(), reason: '' });

export default function Leaves() {
  const { user, setUser } = useAuth();
  const toast = useToast();
  const [leaves, setLeaves] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm());
  const [busy, setBusy] = useState(false);
  const [cancelId, setCancelId] = useState(null);

  const load = useCallback(async () => {
    try {
      const [l, me] = await Promise.all([api.get('/leaves/mine'), api.get('/auth/me')]);
      setLeaves(l.data);
      setUser(me.data); // keeps the leave balance fresh
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const days =
    form.fromDate && form.toDate ? Math.round((new Date(form.toDate) - new Date(form.fromDate)) / 86400000) + 1 : 0;

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.post('/leaves', form);
      toast.success('Leave request submitted');
      setShowForm(false);
      setForm(emptyForm());
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const cancel = async () => {
    setBusy(true);
    try {
      await api.delete(`/leaves/${cancelId}`);
      toast.success('Leave request cancelled');
      setCancelId(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  if (!leaves) return <Loader />;

  return (
    <>
      <PageHeader title="My Leaves" subtitle="Apply for leave and track your requests">
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>
          <i className="bi bi-plus-lg me-2" />Apply for leave
        </button>
      </PageHeader>

      <div className="row g-3 mb-4">
        {Object.entries(user.leaveBalance).map(([type, left]) => (
          <div className="col-4" key={type}>
            <div className="balance-ring text-center">
              <div className="fs-2 fw-semibold text-primary">{left}</div>
              <div className="text-muted small">{capitalize(type)} leave left</div>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-header">Leave history</div>
        {leaves.length === 0 ? (
          <Empty icon="airplane" text="You have not applied for any leave yet" />
        ) : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead>
                <tr><th>Type</th><th>From</th><th>To</th><th>Days</th><th>Reason</th><th>Status</th><th>Reviewer note</th><th /></tr>
              </thead>
              <tbody>
                {leaves.map((l) => (
                  <tr key={l._id}>
                    <td>{capitalize(l.leaveType)}</td>
                    <td>{fmtDate(l.fromDate)}</td>
                    <td>{fmtDate(l.toDate)}</td>
                    <td>{l.days}</td>
                    <td style={{ maxWidth: 220 }} className="text-truncate" title={l.reason}>{l.reason}</td>
                    <td><StatusBadge value={l.status} /></td>
                    <td className="small text-muted">
                      {l.reviewedBy ? `${l.reviewedBy.name}${l.reviewNote ? `: ${l.reviewNote}` : ''}` : '—'}
                    </td>
                    <td className="text-end">
                      {l.status === 'pending' && (
                        <button className="btn btn-sm btn-outline-danger" onClick={() => setCancelId(l._id)}>Cancel</button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showForm && (
        <Modal title="Apply for leave" onClose={() => setShowForm(false)} onSubmit={submit} submitLabel="Submit request" busy={busy}>
          <div className="mb-3">
            <label className="form-label">Leave type</label>
            <select className="form-select" value={form.leaveType} onChange={set('leaveType')}>
              <option value="casual">Casual ({user.leaveBalance.casual} left)</option>
              <option value="sick">Sick ({user.leaveBalance.sick} left)</option>
              <option value="earned">Earned ({user.leaveBalance.earned} left)</option>
              <option value="unpaid">Unpaid</option>
            </select>
          </div>
          <div className="row g-3 mb-3">
            <div className="col-6">
              <label className="form-label">From</label>
              <input type="date" className="form-control" value={form.fromDate} onChange={set('fromDate')} required />
            </div>
            <div className="col-6">
              <label className="form-label">To</label>
              <input type="date" className="form-control" value={form.toDate} min={form.fromDate} onChange={set('toDate')} required />
            </div>
          </div>
          {days > 0 && <div className="small text-muted mb-3">Total: <b>{days}</b> day(s)</div>}
          <div>
            <label className="form-label">Reason</label>
            <textarea className="form-control" rows={3} maxLength={500} value={form.reason} onChange={set('reason')} required />
          </div>
        </Modal>
      )}

      {cancelId && (
        <ConfirmModal
          title="Cancel request"
          message="Do you want to cancel this leave request?"
          confirmLabel="Yes, cancel it"
          busy={busy}
          onConfirm={cancel}
          onClose={() => setCancelId(null)}
        />
      )}
    </>
  );
}
