import { useCallback, useEffect, useMemo, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ConfirmModal, Empty, Loader, Modal, PageHeader, StatusBadge } from '../components/ui';
import { fmtDate, roleLabel, todayISO, toInputDate } from '../utils';

const emptyForm = () => ({
  name: '', email: '', password: '', role: 'employee', department: '', designation: '',
  phone: '', salary: '', manager: '', joiningDate: todayISO(), isActive: true,
});

export default function Employees() {
  const { user } = useAuth();
  const toast = useToast();
  const isHR = user.role === 'hr';

  const [list, setList] = useState(null);
  const [managers, setManagers] = useState([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [editing, setEditing] = useState(null); // null | 'new' | employee
  const [form, setForm] = useState(emptyForm());
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const calls = [api.get('/employees')];
      if (isHR) calls.push(api.get('/employees/managers'));
      const [emp, mgr] = await Promise.all(calls);
      setList(emp.data);
      if (mgr) setManagers(mgr.data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, [isHR]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const shown = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (list || []).filter(
      (e) =>
        (!roleFilter || e.role === roleFilter) &&
        (!q || [e.name, e.email, e.department, e.designation].some((v) => (v || '').toLowerCase().includes(q)))
    );
  }, [list, search, roleFilter]);

  const openNew = () => {
    setForm(emptyForm());
    setEditing('new');
  };

  const openEdit = (emp) => {
    setForm({
      name: emp.name, email: emp.email, password: '', role: emp.role, department: emp.department || '',
      designation: emp.designation || '', phone: emp.phone || '', salary: emp.salary ?? '',
      manager: emp.manager?._id || '', joiningDate: toInputDate(emp.joiningDate), isActive: emp.isActive,
    });
    setEditing(emp);
  };

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      const body = { ...form, salary: form.salary === '' ? 0 : Number(form.salary), manager: form.manager || null };
      if (editing === 'new') {
        await api.post('/employees', body);
        toast.success('Employee added');
      } else {
        if (!body.password) delete body.password;
        await api.put(`/employees/${editing._id}`, body);
        toast.success('Employee updated');
      }
      setEditing(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async () => {
    setBusy(true);
    try {
      await api.delete(`/employees/${deleting._id}`);
      toast.success('Employee deleted');
      setDeleting(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader
        title={isHR ? 'Employees' : 'My Team'}
        subtitle={isHR ? 'Manage employee records' : 'People who report to you'}
      >
        {isHR && (
          <button className="btn btn-primary" onClick={openNew}>
            <i className="bi bi-person-plus me-2" />Add employee
          </button>
        )}
      </PageHeader>

      <div className="card">
        <div className="card-body border-bottom d-flex flex-wrap gap-2">
          <div className="input-group" style={{ maxWidth: 320 }}>
            <span className="input-group-text bg-white"><i className="bi bi-search" /></span>
            <input className="form-control" placeholder="Search name, email, department..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          {isHR && (
            <select className="form-select w-auto" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
              <option value="">All roles</option>
              <option value="hr">HR</option>
              <option value="manager">Manager</option>
              <option value="employee">Employee</option>
            </select>
          )}
          <span className="ms-auto text-muted align-self-center small">{shown.length} people</span>
        </div>

        {!list ? (
          <Loader />
        ) : shown.length === 0 ? (
          <Empty icon="people" text="No employees found" />
        ) : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead>
                <tr>
                  <th>Name</th><th>Role</th><th>Department</th><th>Reports to</th><th>Joined</th>
                  {isHR && <th>Salary</th>}
                  <th>Status</th>
                  {isHR && <th />}
                </tr>
              </thead>
              <tbody>
                {shown.map((emp) => (
                  <tr key={emp._id}>
                    <td>
                      <div className="fw-medium">{emp.name}</div>
                      <small className="text-muted">{emp.email}</small>
                    </td>
                    <td><StatusBadge value={emp.role} label={roleLabel[emp.role]} /></td>
                    <td>
                      {emp.department}
                      <div className="small text-muted">{emp.designation}</div>
                    </td>
                    <td>{emp.manager?.name || '—'}</td>
                    <td className="text-nowrap">{fmtDate(emp.joiningDate)}</td>
                    {isHR && <td>₹{(emp.salary || 0).toLocaleString('en-IN')}</td>}
                    <td><StatusBadge value={emp.isActive ? 'active' : 'inactive'} /></td>
                    {isHR && (
                      <td className="text-end text-nowrap">
                        <button className="btn btn-sm btn-outline-primary me-1" onClick={() => openEdit(emp)}>
                          <i className="bi bi-pencil" />
                        </button>
                        <button
                          className="btn btn-sm btn-outline-danger"
                          disabled={emp._id === user._id}
                          onClick={() => setDeleting(emp)}
                        >
                          <i className="bi bi-trash" />
                        </button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editing && (
        <Modal
          title={editing === 'new' ? 'Add employee' : `Edit ${editing.name}`}
          onClose={() => setEditing(null)}
          onSubmit={save}
          submitLabel={editing === 'new' ? 'Add employee' : 'Save changes'}
          busy={busy}
          size="lg"
        >
          <div className="row g-3">
            <div className="col-md-6">
              <label className="form-label">Full name *</label>
              <input className="form-control" value={form.name} onChange={set('name')} required />
            </div>
            <div className="col-md-6">
              <label className="form-label">Email *</label>
              <input type="email" className="form-control" value={form.email} onChange={set('email')} required />
            </div>
            <div className="col-md-6">
              <label className="form-label">{editing === 'new' ? 'Password *' : 'New password (leave empty to keep)'}</label>
              <input
                type="password"
                className="form-control"
                value={form.password}
                onChange={set('password')}
                minLength={6}
                required={editing === 'new'}
              />
            </div>
            <div className="col-md-6">
              <label className="form-label">Phone</label>
              <input className="form-control" value={form.phone} onChange={set('phone')} />
            </div>
            <div className="col-md-4">
              <label className="form-label">Role</label>
              <select className="form-select" value={form.role} onChange={set('role')}>
                <option value="employee">Employee</option>
                <option value="manager">Manager</option>
                <option value="hr">HR</option>
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Department</label>
              <input className="form-control" value={form.department} onChange={set('department')} />
            </div>
            <div className="col-md-4">
              <label className="form-label">Designation</label>
              <input className="form-control" value={form.designation} onChange={set('designation')} />
            </div>
            <div className="col-md-4">
              <label className="form-label">Reports to</label>
              <select className="form-select" value={form.manager} onChange={set('manager')}>
                <option value="">— None —</option>
                {managers
                  .filter((m) => editing === 'new' || m._id !== editing._id)
                  .map((m) => (
                    <option key={m._id} value={m._id}>{m.name}</option>
                  ))}
              </select>
            </div>
            <div className="col-md-4">
              <label className="form-label">Salary (₹ / month)</label>
              <input type="number" min="0" className="form-control" value={form.salary} onChange={set('salary')} />
            </div>
            <div className="col-md-4">
              <label className="form-label">Joining date</label>
              <input type="date" className="form-control" value={form.joiningDate} onChange={set('joiningDate')} />
            </div>
            <div className="col-12">
              <div className="form-check form-switch">
                <input
                  className="form-check-input"
                  type="checkbox"
                  id="isActive"
                  checked={form.isActive}
                  onChange={set('isActive')}
                  disabled={editing !== 'new' && editing._id === user._id}
                />
                <label className="form-check-label" htmlFor="isActive">Account is active (can log in)</label>
              </div>
            </div>
          </div>
        </Modal>
      )}

      {deleting && (
        <ConfirmModal
          title="Delete employee"
          message={`Delete ${deleting.name}? Their attendance and leave records will also be removed. This cannot be undone.`}
          busy={busy}
          onConfirm={remove}
          onClose={() => setDeleting(null)}
        />
      )}
    </>
  );
}
