import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Empty, Loader, PageHeader, StatusBadge } from '../components/ui';
import { fmtDay, fmtTime, monthISO, todayISO } from '../utils';

// ---------- My attendance: check in/out + monthly history ----------
function MyAttendance() {
  const toast = useToast();
  const [today, setToday] = useState(undefined);
  const [month, setMonth] = useState(monthISO());
  const [history, setHistory] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try {
      const [t, h] = await Promise.all([api.get('/attendance/today'), api.get(`/attendance/mine?month=${month}`)]);
      setToday(t.data);
      setHistory(h.data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, [month]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const punch = async (kind) => {
    setBusy(true);
    try {
      await api.post(`/attendance/${kind}`);
      toast.success(kind === 'check-in' ? 'Checked in. Have a great day!' : 'Checked out. See you tomorrow!');
      await load();
    } catch (e) {
      toast.error(errMsg(e));
    } finally {
      setBusy(false);
    }
  };

  if (today === undefined || !history) return <Loader />;

  return (
    <>
      <div className="card mb-4">
        <div className="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
          <div>
            <div className="text-muted small">Today · {fmtDay(todayISO())}</div>
            {!today && <div className="fs-5 fw-semibold">You have not checked in yet</div>}
            {today && (
              <div className="fs-5 fw-semibold">
                In {fmtTime(today.checkIn)}
                {today.checkOut ? ` · Out ${fmtTime(today.checkOut)}` : ' · Working'}
                <span className="ms-2"><StatusBadge value={today.status} /></span>
              </div>
            )}
          </div>
          <div>
            {!today && (
              <button className="btn btn-primary" disabled={busy} onClick={() => punch('check-in')}>
                <i className="bi bi-box-arrow-in-right me-2" />Check in
              </button>
            )}
            {today && !today.checkOut && (
              <button className="btn btn-dark" disabled={busy} onClick={() => punch('check-out')}>
                <i className="bi bi-box-arrow-right me-2" />Check out
              </button>
            )}
            {today?.checkOut && <span className="text-success"><i className="bi bi-check-circle-fill me-1" />Day completed</span>}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
          <span>History</span>
          <input
            type="month"
            className="form-control form-control-sm w-auto"
            value={month}
            max={monthISO()}
            onChange={(e) => e.target.value && setMonth(e.target.value)}
          />
        </div>
        <div className="card-body border-bottom d-flex flex-wrap gap-3 small">
          <span><StatusBadge value="present" /> {history.summary.present}</span>
          <span><StatusBadge value="late" /> {history.summary.late}</span>
          <span><StatusBadge value="half-day" /> {history.summary.halfDay}</span>
          <span className="text-muted ms-auto">Total hours: <b>{history.summary.totalHours}</b></span>
        </div>
        {history.records.length === 0 ? (
          <Empty icon="calendar-x" text="No attendance records for this month" />
        ) : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead>
                <tr><th>Date</th><th>Check in</th><th>Check out</th><th>Hours</th><th>Status</th></tr>
              </thead>
              <tbody>
                {history.records.map((r) => (
                  <tr key={r._id}>
                    <td>{fmtDay(r.date)}</td>
                    <td>{fmtTime(r.checkIn)}</td>
                    <td>{fmtTime(r.checkOut)}</td>
                    <td>{r.checkOut ? r.workedHours : '—'}</td>
                    <td><StatusBadge value={r.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </>
  );
}

// ---------- Team attendance (HR / manager) ----------
function TeamAttendance() {
  const toast = useToast();
  const [date, setDate] = useState(todayISO());
  const [rows, setRows] = useState(null);

  useEffect(() => {
    setRows(null);
    api
      .get(`/attendance?date=${date}`)
      .then((r) => setRows(r.data.rows))
      .catch((e) => toast.error(errMsg(e)));
  }, [date]); // eslint-disable-line react-hooks/exhaustive-deps

  const count = (s) => (rows || []).filter((r) => r.status === s).length;

  return (
    <div className="card">
      <div className="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
        <span>Attendance sheet</span>
        <input
          type="date"
          className="form-control form-control-sm w-auto"
          value={date}
          max={todayISO()}
          onChange={(e) => e.target.value && setDate(e.target.value)}
        />
      </div>
      {!rows ? (
        <Loader />
      ) : rows.length === 0 ? (
        <Empty icon="people" text="No people to show" />
      ) : (
        <>
          <div className="card-body border-bottom d-flex flex-wrap gap-3 small">
            <span><StatusBadge value="present" /> {count('present')}</span>
            <span><StatusBadge value="late" /> {count('late')}</span>
            <span><StatusBadge value="half-day" /> {count('half-day')}</span>
            <span><StatusBadge value="absent" /> {count('absent')}</span>
          </div>
          <div className="table-responsive">
            <table className="table mb-0">
              <thead>
                <tr><th>Name</th><th>Department</th><th>Check in</th><th>Check out</th><th>Status</th></tr>
              </thead>
              <tbody>
                {rows.map(({ user, record, status }) => (
                  <tr key={user._id}>
                    <td>
                      <div className="fw-medium">{user.name}</div>
                      <small className="text-muted">{user.designation}</small>
                    </td>
                    <td>{user.department}</td>
                    <td>{fmtTime(record?.checkIn)}</td>
                    <td>{fmtTime(record?.checkOut)}</td>
                    <td><StatusBadge value={status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

export default function Attendance() {
  const { user } = useAuth();
  const [tab, setTab] = useState('mine');
  const canSeeTeam = user.role === 'hr' || user.role === 'manager';

  return (
    <>
      <PageHeader title="Attendance" subtitle="Mark your attendance and review your records" />
      {canSeeTeam && (
        <ul className="nav nav-pills mb-3 gap-1">
          <li className="nav-item">
            <button className={`nav-link ${tab === 'mine' ? 'active' : ''}`} onClick={() => setTab('mine')}>My attendance</button>
          </li>
          <li className="nav-item">
            <button className={`nav-link ${tab === 'team' ? 'active' : ''}`} onClick={() => setTab('team')}>
              {user.role === 'hr' ? 'All employees' : 'My team'}
            </button>
          </li>
        </ul>
      )}
      {tab === 'mine' ? <MyAttendance /> : <TeamAttendance />}
    </>
  );
}
