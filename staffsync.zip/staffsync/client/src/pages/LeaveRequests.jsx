import { useCallback, useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Empty, Loader, Modal, PageHeader, StatusBadge } from '../components/ui';
import { capitalize, fmtDate } from '../utils';

const FILTERS = ['pending', 'approved', 'rejected', 'all'];

export default function LeaveRequests() {
  const { user } = useAuth();
  const toast = useToast();
  const [status, setStatus] = useState('pending');
  const [leaves, setLeaves] = useState(null);
  const [review, setReview] = useState(null); // { leave, decision }
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setLeaves(null);
    try {
      const { data } = await api.get('/leaves', { params: status === 'all' ? {} : { status } });
      setLeaves(data);
    } catch (e) {
      toast.error(errMsg(e));
    }
  }, [status]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    load();
  }, [load]);

  const openReview = (leave, decision) => {
    setReview({ leave, decision });
    setNote('');
  };

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await api.put(`/leaves/${review.leave._id}/status`, { status: review.decision, note });
      toast.success(`Leave ${review.decision}`);
      setReview(null);
      await load();
    } catch (err) {
      toast.error(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <PageHeader
        title="Leave Requests"
        subtitle={user.role === 'hr' ? 'Requests from all employees' : 'Requests from your team'}
      />

      <ul className="nav nav-pills mb-3 gap-1">
        {FILTERS.map((f) => (
          <li className="nav-item" key={f}>
            <button className={`nav-link ${status === f ? 'active' : ''}`} onClick={() => setStatus(f)}>
              {capitalize(f)}
            </button>
          </li>
        ))}
      </ul>

      <div className="card">
        {!leaves ? (
          <Loader />
        ) : leaves.length === 0 ? (
          <Empty icon="inbox" text={`No ${status === 'all' ? '' : status} requests`} />
        ) : (
          <div className="table-responsive">
            <table className="table mb-0">
              <thead>
                <tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Reason</th><th>Status</th><th /></tr>
              </thead>
              <tbody>
                {leaves.map((l) => {
                  const own = l.user?._id === user._id;
                  return (
                    <tr key={l._id}>
                      <td>
                        <div className="fw-medium">{l.user?.name}{own && <span className="text-muted"> (you)</span>}</div>
                        <small className="text-muted">{l.user?.department}</small>
                      </td>
                      <td>{capitalize(l.leaveType)}</td>
                      <td className="text-nowrap">{fmtDate(l.fromDate)} – {fmtDate(l.toDate)}</td>
                      <td>{l.days}</td>
                      <td style={{ maxWidth: 220 }} className="text-truncate" title={l.reason}>{l.reason}</td>
                      <td>
                        <StatusBadge value={l.status} />
                        {l.reviewedBy && <div className="small text-muted">by {l.reviewedBy.name}</div>}
                      </td>
                      <td className="text-end text-nowrap">
                        {l.status === 'pending' && !own && (
                          <>
                            <button className="btn btn-sm btn-success me-1" onClick={() => openReview(l, 'approved')}>Approve</button>
                            <button className="btn btn-sm btn-outline-danger" onClick={() => openReview(l, 'rejected')}>Reject</button>
                          </>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {review && (
        <Modal
          title={`${review.decision === 'approved' ? 'Approve' : 'Reject'} leave`}
          onClose={() => setReview(null)}
          onSubmit={submit}
          submitLabel={review.decision === 'approved' ? 'Approve' : 'Reject'}
          busy={busy}
        >
          <p>
            <b>{review.leave.user?.name}</b> · {capitalize(review.leave.leaveType)} leave ·{' '}
            {fmtDate(review.leave.fromDate)} to {fmtDate(review.leave.toDate)} ({review.leave.days} day
            {review.leave.days > 1 ? 's' : ''})
          </p>
          <label className="form-label">Note for the employee (optional)</label>
          <textarea className="form-control" rows={3} maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} />
        </Modal>
      )}
    </>
  );
}
