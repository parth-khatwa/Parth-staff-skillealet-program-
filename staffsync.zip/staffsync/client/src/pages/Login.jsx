import { useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { errMsg } from '../api';

const DEMO = [
  { label: 'HR', email: 'hr@staffsync.com', password: 'Hr@12345' },
  { label: 'Manager', email: 'manager@staffsync.com', password: 'Manager@123' },
  { label: 'Employee', email: 'employee@staffsync.com', password: 'Employee@123' },
];

export function AuthHero() {
  return (
    <div className="auth-hero">
      <div className="d-flex align-items-center gap-2 mb-4">
        <span className="brand-mark bg-white text-primary">S</span>
        <span className="fs-4 fw-semibold">StaffSync</span>
      </div>
      <h2 className="fw-semibold mb-3">One place for every HR task</h2>
      <p className="opacity-75 mb-4">
        A modern human resource management solution for HR teams, managers and employees.
      </p>
      <ul className="list-unstyled">
        <li><i className="bi bi-check2-circle me-2" />Attendance with one-click check in / out</li>
        <li><i className="bi bi-check2-circle me-2" />Leave requests with manager and HR approval</li>
        <li><i className="bi bi-check2-circle me-2" />Employee records, news and announcements</li>
        <li><i className="bi bi-check2-circle me-2" />Training and development programmes</li>
      </ul>
    </div>
  );
}

export default function Login() {
  const { user, login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      await login(form.email, form.password);
      navigate(location.state?.from?.pathname || '/', { replace: true });
    } catch (err) {
      setError(errMsg(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-wrap">
      <AuthHero />
      <div className="auth-form">
        <div style={{ width: '100%', maxWidth: 400 }}>
          <h3 className="fw-semibold mb-1">Welcome back</h3>
          <p className="text-muted mb-4">Sign in to your StaffSync account</p>

          {error && <div className="alert alert-danger py-2">{error}</div>}

          <form onSubmit={submit}>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-control"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
                autoFocus
              />
            </div>
            <div className="mb-4">
              <label className="form-label">Password</label>
              <input
                type="password"
                className="form-control"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                required
              />
            </div>
            <button className="btn btn-primary w-100" disabled={busy}>
              {busy && <span className="spinner-border spinner-border-sm me-2" />}
              Sign in
            </button>
          </form>

          <p className="text-center text-muted mt-3 mb-4">
            New employee? <Link to="/register">Create an account</Link>
          </p>

          <div className="border rounded-3 p-3 bg-white">
            <div className="small text-muted mb-2">Demo accounts (after running the seed script):</div>
            <div className="d-flex flex-wrap gap-2">
              {DEMO.map((d) => (
                <button
                  key={d.label}
                  type="button"
                  className="btn btn-outline-primary btn-sm"
                  onClick={() => setForm({ email: d.email, password: d.password })}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
