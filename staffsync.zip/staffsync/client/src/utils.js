// "2026-11-02T00:00:00.000Z" (date only values are stored at UTC midnight) -> "02 Nov 2026"
export const fmtDate = (d) =>
  d
    ? new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' })
    : '—';

// "YYYY-MM-DD" day string used by attendance
export const fmtDay = (s) => (s ? fmtDate(`${s}T00:00:00Z`) : '—');

export const fmtTime = (d) =>
  d ? new Date(d).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) : '—';

export const fmtStamp = (d) =>
  d ? new Date(d).toLocaleString('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

// Today in the browser's local timezone as YYYY-MM-DD (for <input type="date">)
export const todayISO = () => new Date().toLocaleDateString('en-CA');

export const monthISO = () => todayISO().slice(0, 7);

// Value for <input type="date"> from an ISO string
export const toInputDate = (d) => (d ? String(d).slice(0, 10) : '');

export const capitalize = (s = '') => s.charAt(0).toUpperCase() + s.slice(1);

export const roleLabel = { hr: 'HR', manager: 'Manager', employee: 'Employee' };
