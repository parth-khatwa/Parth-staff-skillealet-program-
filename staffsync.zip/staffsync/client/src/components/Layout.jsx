import { useState } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { StatusBadge } from './ui';
import { roleLabel } from '../utils';

const NAV = [
  { to: '/', label: 'Dashboard', icon: 'speedometer2', end: true },
  { to: '/attendance', label: 'Attendance', icon: 'calendar-check' },
  { to: '/leaves', label: 'My Leaves', icon: 'airplane' },
  { to: '/leave-requests', label: 'Leave Requests', icon: 'inbox', roles: ['hr', 'manager'] },
  { to: '/employees', label: 'Employees', icon: 'people', roles: ['hr'] },
  { to: '/employees', label: 'My Team', icon: 'people', roles: ['manager'] },
  { to: '/announcements', label: 'Announcements', icon: 'megaphone' },
  { to: '/trainings', label: 'Training', icon: 'mortarboard' },
  { to: '/profile', label: 'My Profile', icon: 'person-circle' },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const items = NAV.filter((n) => !n.roles || n.roles.includes(user.role));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="brand">
          <span className="brand-mark">S</span>
          <span className="fw-semibold fs-5">StaffSync</span>
        </div>
        <nav className="nav flex-column gap-1 px-2">
          {items.map((n) => (
            <NavLink
              key={n.label}
              to={n.to}
              end={n.end}
              className="side-link"
              onClick={() => setOpen(false)}
            >
              <i className={`bi bi-${n.icon}`} />
              <span>{n.label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="mt-auto p-3">
          <button className="btn btn-outline-light btn-sm w-100" onClick={handleLogout}>
            <i className="bi bi-box-arrow-right me-2" />
            Logout
          </button>
        </div>
      </aside>
      {open && <div className="sidebar-scrim" onClick={() => setOpen(false)} />}

      <div className="main">
        <header className="topbar">
          <button className="btn btn-light d-lg-none" onClick={() => setOpen(true)} aria-label="Open menu">
            <i className="bi bi-list fs-5" />
          </button>
          <div className="ms-auto d-flex align-items-center gap-3">
            <div className="text-end lh-sm d-none d-sm-block">
              <div className="fw-medium">{user.name}</div>
              <small className="text-muted">{user.designation}</small>
            </div>
            <StatusBadge value={user.role} label={roleLabel[user.role]} />
            <span className="avatar">{user.name.charAt(0).toUpperCase()}</span>
          </div>
        </header>
        <main className="content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
