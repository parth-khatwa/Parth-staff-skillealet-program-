import { useEffect } from 'react';

// ---------- Loader ----------
export function Loader({ text = 'Loading...' }) {
  return (
    <div className="d-flex flex-column align-items-center justify-content-center py-5 text-muted">
      <div className="spinner-border text-primary mb-2" role="status" />
      <small>{text}</small>
    </div>
  );
}

// ---------- Empty state ----------
export function Empty({ icon = 'inbox', text = 'Nothing to show yet' }) {
  return (
    <div className="text-center text-muted py-5">
      <i className={`bi bi-${icon} fs-1 d-block mb-2 opacity-50`} />
      <div>{text}</div>
    </div>
  );
}

// ---------- Page heading ----------
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="d-flex flex-wrap align-items-center justify-content-between gap-2 mb-4">
      <div>
        <h1 className="h3 mb-0 fw-semibold">{title}</h1>
        {subtitle && <div className="text-muted">{subtitle}</div>}
      </div>
      <div className="d-flex gap-2">{children}</div>
    </div>
  );
}

// ---------- Coloured status pill ----------
const COLORS = {
  pending: 'warning',
  approved: 'success',
  rejected: 'danger',
  present: 'success',
  late: 'warning',
  'half-day': 'info',
  absent: 'danger',
  upcoming: 'info',
  ongoing: 'primary',
  completed: 'success',
  hr: 'danger',
  manager: 'primary',
  employee: 'secondary',
  active: 'success',
  inactive: 'secondary',
  announcement: 'primary',
  news: 'info',
  policy: 'warning',
  event: 'success',
};

export function StatusBadge({ value, label }) {
  const color = COLORS[value] || 'secondary';
  const text = label || (value ? value.charAt(0).toUpperCase() + value.slice(1) : '—');
  return <span className={`badge rounded-pill text-bg-${color} fw-medium`}>{text}</span>;
}

// ---------- Stat tile ----------
export function StatCard({ icon, label, value, color = 'primary' }) {
  return (
    <div className="col-6 col-xl-3">
      <div className="card stat-card h-100">
        <div className="card-body d-flex align-items-center gap-3">
          <span className={`stat-icon bg-${color}-subtle text-${color}`}>
            <i className={`bi bi-${icon}`} />
          </span>
          <div>
            <div className="text-muted small">{label}</div>
            <div className="fs-4 fw-semibold lh-1 mt-1">{value}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------- Modal (plain Bootstrap CSS, no Bootstrap JS needed) ----------
export function Modal({ title, onClose, onSubmit, submitLabel = 'Save', busy = false, size, children, hideFooter }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.classList.add('modal-open');
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.classList.remove('modal-open');
    };
  }, [onClose]);

  const inner = (
    <>
      <div className="modal-header">
        <h5 className="modal-title">{title}</h5>
        <button type="button" className="btn-close" aria-label="Close" onClick={onClose} />
      </div>
      <div className="modal-body">{children}</div>
      {!hideFooter && (
        <div className="modal-footer">
          <button type="button" className="btn btn-light" onClick={onClose}>
            Cancel
          </button>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy && <span className="spinner-border spinner-border-sm me-2" />}
            {submitLabel}
          </button>
        </div>
      )}
    </>
  );

  return (
    <>
      <div
        className="modal fade show d-block"
        tabIndex="-1"
        role="dialog"
        onMouseDown={(e) => e.target === e.currentTarget && onClose()}
      >
        <div className={`modal-dialog modal-dialog-scrollable modal-dialog-centered ${size ? `modal-${size}` : ''}`}>
          <div className="modal-content border-0 shadow">
            {onSubmit ? <form onSubmit={onSubmit} className="d-flex flex-column overflow-hidden">{inner}</form> : inner}
          </div>
        </div>
      </div>
      <div className="modal-backdrop fade show" />
    </>
  );
}

// ---------- Confirm helper ----------
export function ConfirmModal({ title = 'Are you sure?', message, confirmLabel = 'Delete', busy, onConfirm, onClose }) {
  return (
    <Modal
      title={title}
      onClose={onClose}
      onSubmit={(e) => {
        e.preventDefault();
        onConfirm();
      }}
      submitLabel={confirmLabel}
      busy={busy}
      size="sm"
    >
      <p className="mb-0">{message}</p>
    </Modal>
  );
}
